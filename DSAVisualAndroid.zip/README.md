# DSA Visual Android

Offline Android prototype for visualizing data structures and algorithms.

## Design goals

- Runs entirely offline after installation.
- Targets low-end Android hardware.
- Native Android custom `Canvas` rendering rather than WebView.
- No runtime network calls.
- Minimal external dependencies.
- Algorithm/step engine kept separate from rendering.

## Current prototype

Array traversal with:

- Forward sum
- Reverse sum
- Max scan
- Linear search
- Previous / Next
- Play / Pause
- Reset
- Playback speed control

## Next

The architecture is intentionally small so more structures can be added without
rewriting the renderer:

- Binary search
- Two pointers
- Sliding window
- Linked list
- Stack / Queue
- Trees
- Sorting
- Graphs

The original desktop repository remains the reference for the broader
visualization design.
