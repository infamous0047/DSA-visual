package dsa.visual.android.core;

import java.util.ArrayList;
import java.util.List;

public final class ArrayTraversal {
    private final int[] data;
    private final int target;

    public ArrayTraversal(int[] data, int target) {
        this.data = data.clone();
        this.target = target;
    }

    public List<VisualizationEngine.Step> build() {
        List<VisualizationEngine.Step> steps = new ArrayList<>();
        forward(steps);
        reverse(steps);
        maxScan(steps);
        linearSearch(steps);
        return steps;
    }

    private void forward(List<VisualizationEngine.Step> s) {
        int sum = 0;
        add(s, "Forward sum: start with sum = 0.",
                new ArrayState(data, -1, 0, -1, -1, ArrayState.Mode.FORWARD_SUM));
        for (int i = 0; i < data.length; i++) {
            sum += data[i];
            add(s, "Visit data[" + i + "] = " + data[i] + "  ->  sum = " + sum,
                    new ArrayState(data, i, sum, -1, -1, ArrayState.Mode.FORWARD_SUM));
        }
    }

    private void reverse(List<VisualizationEngine.Step> s) {
        int sum = 0;
        for (int i = data.length - 1; i >= 0; i--) {
            sum += data[i];
            add(s, "Visit data[" + i + "] = " + data[i] + "  ->  sum = " + sum,
                    new ArrayState(data, i, sum, -1, -1, ArrayState.Mode.REVERSE_SUM));
        }
    }

    private void maxScan(List<VisualizationEngine.Step> s) {
        int maxIndex = 0;
        add(s, "Max scan: assume data[0] is the max.",
                new ArrayState(data, 0, data[0], maxIndex, -1, ArrayState.Mode.MAX_SCAN));
        for (int i = 1; i < data.length; i++) {
            if (data[i] > data[maxIndex]) maxIndex = i;
            add(s, "Compare data[" + i + "] with current max.",
                    new ArrayState(data, i, data[maxIndex], maxIndex, -1, ArrayState.Mode.MAX_SCAN));
        }
    }

    private void linearSearch(List<VisualizationEngine.Step> s) {
        for (int i = 0; i < data.length; i++) {
            boolean found = data[i] == target;
            add(s, "Compare data[" + i + "] = " + data[i]
                    + (found ? "  ->  FOUND" : "  ->  not a match"),
                    new ArrayState(data, i, target, -1,
                            found ? i : -1, ArrayState.Mode.LINEAR_SEARCH));
            if (found) return;
        }
        add(s, "Target " + target + " was not found.",
                new ArrayState(data, data.length - 1, target, -1, -1,
                        ArrayState.Mode.LINEAR_SEARCH));
    }

    private void add(List<VisualizationEngine.Step> steps, String text, ArrayState state) {
        steps.add(new VisualizationEngine.Step(text, state));
    }
}
