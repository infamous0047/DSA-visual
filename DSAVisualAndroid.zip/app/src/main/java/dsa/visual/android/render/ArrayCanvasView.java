package dsa.visual.android.render;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

import dsa.visual.android.core.ArrayState;

public final class ArrayCanvasView extends View {
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private ArrayState state;

    public ArrayCanvasView(Context context) {
        super(context);
        fill.setStyle(Paint.Style.FILL);
        text.setTextSize(34);
        text.setTextAlign(Paint.Align.CENTER);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(4);
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
    }

    public void setState(ArrayState state) {
        this.state = state;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        canvas.drawColor(0xFF15171B);

        if (state == null || state.data.length == 0) return;

        float width = getWidth();
        float cell = Math.min(92f, (width - 32f) / state.data.length);
        float total = cell * state.data.length;
        float left = (width - total) / 2f;
        float top = getHeight() * 0.38f;
        float height = 76f;

        for (int i = 0; i < state.data.length; i++) {
            float x = left + i * cell;
            fill.setColor(i == state.currentIndex ? 0xFF263F69 : 0xFF202329);
            canvas.drawRoundRect(new RectF(x + 2, top, x + cell - 2, top + height),
                    10, 10, fill);

            text.setColor(0xFFF4F4F5);
            canvas.drawText(String.valueOf(state.data[i]),
                    x + cell / 2f, top + 49, text);

            text.setTextSize(16);
            text.setColor(0xFF8F949F);
            canvas.drawText(String.valueOf(i),
                    x + cell / 2f, top + height + 28, text);
            text.setTextSize(34);

            if (i == state.maxIndex) {
                stroke.setColor(0xFF55C878);
                stroke.setStrokeWidth(3);
                canvas.drawRoundRect(new RectF(x + 3, top + 3, x + cell - 3, top + height - 3),
                        10, 10, stroke);
            }

            if (i == state.foundIndex) {
                stroke.setColor(0xFFFFC857);
                stroke.setStrokeWidth(5);
                canvas.drawRoundRect(new RectF(x, top - 2, x + cell, top + height + 2),
                        10, 10, stroke);
            }
        }

        text.setTextSize(18);
        text.setColor(0xFFB8BBC2);
        String phase = state.mode.name().replace('_', ' ');
        canvas.drawText(phase + "    value = " + state.accumulator,
                width / 2f, top - 38, text);
        text.setTextSize(34);
    }
}
