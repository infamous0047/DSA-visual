package dsa.visual.android.core;

public final class ArrayState {
    public enum Mode { FORWARD_SUM, REVERSE_SUM, MAX_SCAN, LINEAR_SEARCH }

    public final int[] data;
    public final int currentIndex;
    public final int accumulator;
    public final int maxIndex;
    public final int foundIndex;
    public final Mode mode;

    public ArrayState(int[] data, int currentIndex, int accumulator,
                      int maxIndex, int foundIndex, Mode mode) {
        this.data = data.clone();
        this.currentIndex = currentIndex;
        this.accumulator = accumulator;
        this.maxIndex = maxIndex;
        this.foundIndex = foundIndex;
        this.mode = mode;
    }
}
