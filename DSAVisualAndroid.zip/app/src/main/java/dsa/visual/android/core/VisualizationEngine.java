package dsa.visual.android.core;

import android.os.Handler;
import android.os.Looper;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class VisualizationEngine {
    public interface Listener {
        void onStep(Step step);
    }

    public static final class Step {
        public final String description;
        public final ArrayState state;

        public Step(String description, ArrayState state) {
            this.description = description;
            this.state = state;
        }
    }

    private final List<Step> steps = new ArrayList<>();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private Listener listener;
    private int current = -1;
    private long delayMillis = 400;
    private boolean playing;

    private final Runnable player = new Runnable() {
        @Override public void run() {
            if (!playing) return;
            if (!next()) {
                playing = false;
                return;
            }
            handler.postDelayed(this, delayMillis);
        }
    };

    public void record(List<Step> newSteps) {
        stop();
        steps.clear();
        steps.addAll(newSteps);
        current = steps.isEmpty() ? -1 : 0;
    }

    public List<Step> steps() {
        return Collections.unmodifiableList(steps);
    }

    public int size() { return steps.size(); }
    public int currentIndex() { return current; }
    public boolean isPlaying() { return playing; }
    public Step currentStep() {
        return current >= 0 && current < steps.size() ? steps.get(current) : null;
    }

    public void setListener(Listener listener) {
        this.listener = listener;
    }

    public void setDelayMillis(long millis) {
        delayMillis = Math.max(80, millis);
    }

    public void reset() {
        stop();
        current = steps.isEmpty() ? -1 : 0;
        notifyStep();
    }

    public boolean next() {
        if (current + 1 >= steps.size()) return false;
        current++;
        notifyStep();
        return true;
    }

    public boolean prev() {
        if (current <= 0) return false;
        current--;
        notifyStep();
        return true;
    }

    public void play() {
        if (playing || steps.isEmpty()) return;
        if (current >= steps.size() - 1) current = 0;
        playing = true;
        notifyStep();
        handler.postDelayed(player, delayMillis);
    }

    public void stop() {
        playing = false;
        handler.removeCallbacks(player);
    }

    private void notifyStep() {
        if (listener != null) listener.onStep(currentStep());
    }
}
