package dsa.visual.android;

import android.app.Activity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import dsa.visual.android.core.ArrayTraversal;
import dsa.visual.android.core.VisualizationEngine;
import dsa.visual.android.render.ArrayCanvasView;

public final class MainActivity extends Activity {
    private VisualizationEngine engine;
    private ArrayCanvasView canvas;
    private TextView stepLabel;
    private Button playButton;
    private int[] data = {3, 1, 7, 4, 9, 2, 5};

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);

        engine = new VisualizationEngine();
        canvas = new ArrayCanvasView(this);
        stepLabel = new TextView(this);
        playButton = new Button(this);
        playButton.setText("PLAY");

        rebuild();

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(16, 12, 16, 12);
        root.setBackgroundColor(0xFF101114);

        TextView title = new TextView(this);
        title.setText("DSA Visual  •  Array Traversal");
        title.setTextColor(0xFFF4F4F5);
        title.setTextSize(20);
        title.setGravity(Gravity.CENTER_VERTICAL);
        root.addView(title, new LinearLayout.LayoutParams(-1, 52));

        root.addView(canvas, new LinearLayout.LayoutParams(-1, 0, 1));

        stepLabel.setTextColor(0xFFB8BBC2);
        stepLabel.setTextSize(14);
        stepLabel.setPadding(4, 8, 4, 8);
        root.addView(stepLabel, new LinearLayout.LayoutParams(-1, 44));

        LinearLayout controls = new LinearLayout(this);
        controls.setGravity(Gravity.CENTER);
        controls.setOrientation(LinearLayout.HORIZONTAL);

        Button prev = new Button(this);
        prev.setText("PREV");
        Button next = new Button(this);
        next.setText("NEXT");
        Button reset = new Button(this);
        reset.setText("RESET");

        controls.addView(prev, new LinearLayout.LayoutParams(0, 52, 1));
        controls.addView(playButton, new LinearLayout.LayoutParams(0, 52, 1));
        controls.addView(next, new LinearLayout.LayoutParams(0, 52, 1));
        controls.addView(reset, new LinearLayout.LayoutParams(0, 52, 1));
        root.addView(controls);

        SeekBar speed = new SeekBar(this);
        speed.setMax(900);
        speed.setProgress(600);
        root.addView(speed, new LinearLayout.LayoutParams(-1, 48));

        setContentView(root);

        prev.setOnClickListener(v -> {
            engine.prev();
            updateUi();
        });

        next.setOnClickListener(v -> {
            engine.next();
            updateUi();
        });

        reset.setOnClickListener(v -> {
            engine.reset();
            updateUi();
        });

        playButton.setOnClickListener(v -> {
            if (engine.isPlaying()) {
                engine.stop();
            } else {
                engine.play();
            }
            updateUi();
        });

        speed.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                engine.setDelayMillis(100 + (900 - progress));
            }
            @Override public void onStartTrackingTouch(SeekBar bar) {}
            @Override public void onStopTrackingTouch(SeekBar bar) {}
        });

        updateUi();
    }

    private void rebuild() {
        engine.record(new ArrayTraversal(data, 9).build());
        engine.setListener(step -> {
            canvas.setState(step.state);
            runOnUiThread(this::updateUi);
        });
        engine.reset();
    }

    private void updateUi() {
        canvas.invalidate();
        VisualizationEngine.Step step = engine.currentStep();
        if (step == null) {
            stepLabel.setText("No steps");
        } else {
            stepLabel.setText((engine.currentIndex() + 1) + " / " + engine.size()
                    + "   " + step.description);
        }
        playButton.setText(engine.isPlaying() ? "PAUSE" : "PLAY");
    }

    @Override
    protected void onPause() {
        engine.stop();
        super.onPause();
    }
}
